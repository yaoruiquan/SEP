Test file for SKILL.md
